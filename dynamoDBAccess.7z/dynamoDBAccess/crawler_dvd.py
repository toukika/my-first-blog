import csv,os,json
import requests
import re
import time
import lxml.html
from lxml import html  
from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from flask import Flask,render_template
import simplejson as json

import boto3

app = Flask(__name__,template_folder='template')

#Dynamodbにアクセスします
dynamodb = boto3.resource('dynamodb', endpoint_url="http://192.168.99.100:8000",
                            region_name='us-west-2',
                            aws_access_key_id='ACCESS_ID',
                            aws_secret_access_key='ACCESS_KEY')

table = dynamodb.Table('scrapy')
#データリストを定義します。
itemsList =[]

#「この商品を買った人はこんな商品も買っています」関連アーティスト名を取得します
def namesParser(nameurl,nameList):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
	response = requests.get(nameurl,headers=headers)
	page = lxml.html.fromstring(response.content)
	findName=''
	#アーティスト名が存在することをチェックします
	if bool(page.xpath('//*[@id="bylineInfo"]/span[1]/a'))== True:
		findName = page.xpath('//*[@id="bylineInfo"]/span[1]/a')[0].text
	else:
		findName = 'None'
	nameList.append(findName)


#「この商品を買った人はこんな商品も買っています」関連商品詳細を取得します
def divParser(divurl,nameList):
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
	response = requests.get(divurl,headers=headers)
	page = lxml.html.fromstring(response.content)
	time.sleep(5)
	#「この商品を買った人はこんな商品も買っています」が存在するかどうかを判断する
	if bool(page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div')) == True:
		#「この商品を買った人はこんな商品も買っています」のdiv属性を取得します
		findDivTagString = page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div/@data-a-carousel-options')[0] 
		#jsonに変換します
		jsonValue = json.loads(findDivTagString)
		#全ASINを取得します
		itemList = jsonValue["ajax"]["id_list"]
		for item in itemList:
			itemASIN = re.search(r'[A-Z0-9]{10}', item)
			AsinList = []
			AsinList.append(itemASIN.group(0))
			extracted_data = []
			for i in AsinList:
				url = "https://www.amazon.co.jp/dp/"+i
				namesParser(url,nameList)


#カテゴリーはDVDの場合 
def dvdPaser(dvdurl):
	print(dvdurl)
	headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
	response = requests.get(dvdurl,headers=headers)
	page = lxml.html.fromstring(response.content)
	time.sleep(5)
	#商品詳細頁のリンクを取得します
	links = page.xpath('//*[@id="search"]/div[1]/div[2]/div/span[3]/div[1]/div/div/span/div/div/div[2]/div[4]/div/div[1]/div[1]/a/@href')
	for link in links:
		searchASIN = re.search(r'B[A-Z0-9]{9}', link)
		AsinList = []
		AsinList.append(searchASIN.group(0))
		for n in AsinList:
			url = "https://www.amazon.co.jp/dp/" + n
			print("Processing:"+url)
			nameList1 = []
			divParser(url,nameList1)
			sleep(2)
			listSet = set(nameList1)
			for name in nameList1:
				num = nameList1.count(name)
				category="DVD"
				print(name)
				print(num)
				#クロールしたデータを登録します。
				table.put_item( 
					Item={
						'user_id':num,
						'user_name': name,
						'category':category,
						'user_count':num
					}
				)

				item = table.get_item(Key={'user_id':num})
				itemsList.append(item['Item'])
				json.dumps(itemsList)
				print(itemsList)


#カテゴリーページURLを取得します
def ReadAsin(url):
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
	response = requests.get(url,headers=headers)
	time.sleep(5)
	page = lxml.html.fromstring(response.content)
	baseurl = "https://www.amazon.co.jp"
	#カテゴリーDVDのページを取得します
	dvdUrl = page.xpath('//*[@id="p_n_srvg_2374648051/622812011"]/span/a/@href')[0]
	dvdPaser(baseurl+dvdUrl)


@app.route('/')
def index():
	dataList = itemsList
	#テンプレートのディレクトリを指定します
	return render_template('index.html',item_List=dataList)


if __name__=="__main__":
	url = "https://www.amazon.co.jp/s?k=%E3%81%82%E3%81%84%E3%81%BF%E3%82%87%E3%82%93"
	ReadAsin(url)
	app.run(debug = True)