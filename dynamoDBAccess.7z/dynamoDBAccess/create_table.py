import boto3

dynamodb = boto3.resource('dynamodb', endpoint_url="http://192.168.99.100:8000",
                            region_name='us-west-2',
                            aws_access_key_id='ACCESS_ID',
                            aws_secret_access_key='ACCESS_KEY')

table = dynamodb.create_table(
    TableName='scrapy',
    KeySchema=[
        {
            'AttributeName': 'user_id',
            'KeyType': 'HASH'
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'user_id',
            'AttributeType': 'N'
        }
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 5,
        'WriteCapacityUnits': 5
    }
)

print('Table status:', table.table_status)