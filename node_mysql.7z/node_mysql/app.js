/* 1. expressモジュールをロードし、インスタンス化してappに代入。*/
const express = require("express");
const app = express();
const cheerio = require('cheerio');
const superagent= require('superagent'); 
const mysql = require('mysql')

/* 2. listen()メソッドを実行して3000番ポートで待ち受け。*/
let server = app.listen(3000, ()=>{
    console.log("Node.js is listening to PORT:" + server.address().port);
});

let namelist = [];
let categoryPage = [];
let url = 'https://www.amazon.co.jp/s?k=%E3%81%82%E3%81%84%E3%81%BF%E3%82%87%E3%82%93';
let baseurl = 'https://www.amazon.co.jp';


// View EngineにEJSを指定。
app.set('view engine', 'ejs');
//ディレクトリを指定します。
app.use(express.static(__dirname + '/static'));


//mysqlとのコレクションの設定
const connection = mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'password',
	database:'scrapy'
});

//MySQLに接続する
connection.connect();

async function dbInsert(categoryPage){
	await wait(100);
	connection.connect((err)=>{
		if(err){
			console.log('err:'+err);
		}
		var sql = "INSERT INTO mianapp_nameitem (name, number, category) VALUES ?";
		connection.query(sql,[categoryPage],(err,result)=>{
			if(err){
				console.log('err:'+err);
			}
			console.log("successfully INSERT into mysql"+ result.affectedRows)
		});
	});
}

//商品詳細ページのアーティスト名を取得する
async function getName(nameUrl,category){
	await wait(100);
  superagent.get(nameUrl).end((err,res3)=>{
    if(err){
      console.log(`クローラ失敗しました - ${err}`)
    }else{
      let $ = cheerio.load(res3.text)
      //関連商品のアーティスト名存在する場合
      if($('#bylineInfo > span.author.notFaded > a') !== null){
        $('#bylineInfo > span.author.notFaded > a').each((idx,na)=>{
          //関連商品のアーティスト名を取得する
          let name = $(na).text()
          namelist.push(name)
          let object = {}
          for(let i = 0,len = namelist.length;i < len;i++){
            let item = namelist[i]
            object[item] = (object[item] + 1) || 1
          }
          //アーテイスト名、アーテイスト数、カテゴリーをdetailに保存する
          let detail ={
            name: name,
            number:object[item],
            category:category
          }
          console.log(object);
          // 最終結果リストに保存します
          categoryPage.push(detail)
          //mysqlにデータを保存します。
          dbInsert(categoryPage);
        });
      }
    }
  });
}


//「この商品を買った人はこんな商品も買っています」商品詳細ページを取得する
async function getPage(dedailUrl,category){
	await wait(100);
  superagent.get(dedailUrl).end((err,rest)=>{
    if(err){
      console.log(`クローラ失敗しました - ${err}`)
    }else{
      let $ = cheerio.load(rest.text);
      //商品詳細で「この商品を買った人はこんな商品も買っています」項目をチェックする
      if ($('#desktop-dp-sims_purchase-similarities-sims-feature > div') !== null){
        $('#desktop-dp-sims_purchase-similarities-sims-feature > div').each((index,pro)=>{
          let divAtrr = $(pro).attr('data-a-carousel-options')
          let obj = JSON.parse(divAtrr)['ajax']['id_list']
          for (let val of obj){
            //全て項目商品のASINを取得する
            let itemASIN = val.match(/[A-Z0-9]{10}/)
            let nameUrl = baseurl+'/dp/'+itemASIN
            //アーティスト名を取得する
            getName(nameUrl,category);
            console.log(nameUrl);
          }
        });
      }
    }
  });
};


//クローラページ実行
function getProduct($){
  $('#filters > ul:nth-child(8) > li > span > a').each((idx, ele) => {
    let url = $(ele).attr('href')
    let searchUrl = baseurl+url
    //console.log(searchUrl);
    superagent.get(searchUrl).end((err,sres)=>{
      if(err){
        console.log(`クローラ失敗しました - ${err}`)
      }else{
        let $ = cheerio.load(sres.text);
        //ブルーレイの場合
        if(searchUrl.includes("sr_nr_p_n_srvg_2374648051_3")){
          $('#search > div.sg-row > div.sg-col-20-of-24.sg-col-28-of-32.sg-col-16-of-20.sg-col.s-right-column.sg-col-32-of-36.sg-col-8-of-12.sg-col-12-of-16.sg-col-24-of-28 > div > span:nth-child(4) > div.s-result-list.s-search-results.sg-row > div > div > span > div > div > div:nth-child(2) > div:nth-child(1) > div > div > span > a').each((index,element)=>{
            //商品詳細リンクを取得
            let productUrl = $(element).attr('href')
            let dedailUrl = baseurl + productUrl 
            let category="ブルーレイ"
            //「この商品を買った人はこんな商品も買っています」商品詳細ページを取得する
            getPage(dedailUrl,category);
          });
        }
        //DVDの場合
        else if(searchUrl.includes("sr_nr_p_n_srvg_2374648051_2")){
          $('#search > div.sg-row > div.sg-col-20-of-24.sg-col-28-of-32.sg-col-16-of-20.sg-col.s-right-column.sg-col-32-of-36.sg-col-8-of-12.sg-col-12-of-16.sg-col-24-of-28 > div > span:nth-child(4) > div.s-result-list.s-search-results.sg-row > div > div > span > div > div > div:nth-child(2) > div:nth-child(1) > div > div > span > a').each((index,element)=>{
            //商品詳細リンクを取得
            let productUrl = $(element).attr('href')
            let dedailUrl = baseurl + productUrl 
            let category="DVD"
            //「この商品を買った人はこんな商品も買っています」商品詳細ページを取得する
            getPage(dedailUrl,category);
          });
        }
        //CDの場合
        else if(searchUrl.includes("sr_nr_p_n_srvg_2374648051_1")){
          $('#search > div.sg-row > div.sg-col-20-of-24.sg-col-28-of-32.sg-col-16-of-20.sg-col.s-right-column.sg-col-32-of-36.sg-col-8-of-12.sg-col-12-of-16.sg-col-24-of-28 > div > span:nth-child(4) > div.s-result-list.s-search-results.sg-row > div > div > span > div > div > div:nth-child(2) > div:nth-child(1) > div > div > span > a').each((index,element)=>{
            //商品詳細リンクを取得
            let productUrl = $(element).attr('href')
            let dedailUrl = baseurl + productUrl 
            //console.log(dedailUrl);
            let category="CD"
            //「この商品を買った人はこんな商品も買っています」商品詳細ページを取得する
            getPage(dedailUrl,category);
          });
        }
      }
    });
  });
  
};

 
// "/"へのGETリクエストでindex.ejsを表示する。拡張子（.ejs）は省略されていることに注意。
app.get("/", (req, res, next)=>{

	(function(page){
		superagent.get(page).end((err, res) => {
			if (err) {
				// アクセスが失敗するかエラーが発生した場合、この行はここにあります。
				console.log(`クローラ失敗しました - ${err}`)
			}else{
				// 成功したアクセス，要求ページによって返されたデータは、resに含まれます
	        	let $ = cheerio.load(res.text);
	        	//クローラページ実行
	        	getProduct($);
	      	}
	    });
	})(url);

	//最終結果ページに渡す。
	res.render("index", {content: categoryPage});
});



