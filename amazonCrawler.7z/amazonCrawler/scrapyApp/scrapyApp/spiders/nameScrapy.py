# -*- coding: utf-8 -*-
from time import sleep
from bs4 import BeautifulSoup
from lxml import html  
from selenium import webdriver
import scrapy
import csv,os,json
import requests
import re
import time
import lxml.html

#from scrapyApp.items import ScrapyAppItem


class NamescrapySpider(scrapy.Spider):
    name = 'nameScrapy'
    allowed_domains = ['https://www.amazon.co.jp/']
    #start_urls = ['http://https://www.amazon.co.jp//']

    def parse(self, response):
        pass

    def namesParser(searchUrl,nameList):
        #//*[@id="bylineInfo"]/span[1]/a
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
        response = requests.get(searchUrl,headers=headers)
        page = lxml.html.fromstring(response.content)
        time.sleep(5)
        findName = ''
        if bool(page.xpath('//*[@id="bylineInfo"]/span[1]/a'))== True:
            findName = page.xpath('//*[@id="bylineInfo"]/span[1]/a')[0].text
        else:
            findName = ''
       
        nameList.append(findName)
        

    def divParser(url):
        #response = requests.get(url)
        #page = lxml.html.fromstring(response.content)
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
        response = requests.get(url,headers=headers)
        page = lxml.html.fromstring(response.content)
        time.sleep(5)
        #links = soup.find_all('a',href=True)
        nameList = []
        if bool(page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div')) == True:
            findDivTagString = page.xpath('//*[@id="desktop-dp-sims_purchase-similarities-sims-feature"]/div/@data-a-carousel-options')[0] 
            jsonValue = json.loads(findDivTagString)
            itemList = jsonValue["ajax"]["id_list"]
            for item in itemList:
                    itemASIN = re.search(r'[A-Z0-9]{10}', item)
                    AsinList = []
                    AsinList.append(itemASIN.group(0))
                    extracted_data = []
                    for i in AsinList:
                        url = "https://www.amazon.co.jp/dp/"+i
                        print ("nameUrl:"+url)
                        extracted_data.append(namesParser(url,nameList))
                        time.sleep(5)

        print(nameList)            
        list_set = set(nameList)
        for ite in list_set:
            print("the %s has found %d" %(ite,nameList.count(ite))) 
            #item = ScrapyAppItem()
            #item['name'] = ite[0]
            #item['url'] = ite[0]
            #yield item
     

    def ReadAsin():
        searchurl="https://www.amazon.co.jp/s?k=%E3%81%82%E3%81%84%E3%81%BF%E3%82%87%E3%82%93" 
        #response = requests.get(url)
        #page = lxml.html.fromstring(response.content)
        #driver = webdriver.Chrome()
        #driver.get(searchurl)page = requests.get(searchurl,headers=headers)
        #time.sleep(5)
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'}
        page = requests.get(searchurl,headers=headers)
        time.sleep(5)
        soup = BeautifulSoup(page.content,"html.parser")
        #links = soup.find_all('a',href=True)
        allAClass = soup.find_all('a',class_=re.compile(r'a-text-bold'))

        #fetch("https://www.amazon.co.jp/s?k=%E3%81%82%E3%81%84%E3%81%BF%E3%82%87%E3%82%93")
        #response.xpath("//div[@class='sg-col-inner']")
        #products = response.xpath("//div[@class='sg-col-inner']")
        for link in allAClass:
            #print eachPart.get_text()
            links = []
            hrefString = link.string
            if "Blu-ray" in hrefString or "CD" in hrefString or "DVD" in hrefString:
                href = link['href']
                links.append(href)

                for delink in links:
                    searchASIN = re.search(r'B[A-Z0-9]{9}', delink)
                    #print(searchASIN.group(0))
                    AsinList = []
                    AsinList.append(searchASIN.group(0))
                    extracted_data = []

                    for i in AsinList:
                        url = "https://www.amazon.co.jp/dp/"+i
                        print ("Processing:"+url)
                        extracted_data.append(divParser(url))
                        sleep(5)
