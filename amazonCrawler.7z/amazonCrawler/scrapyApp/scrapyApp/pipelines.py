# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from mianApp.models import NameItem

class ScrapyappPipeline(object):
    def process_item(self, item, spider):
        scrapy_item = NameItem()
        scrapy_item.name = item['name']
        scrapy_item.number = item['number']
        scrapy_item.category = item['category']

        scrapy_item.save()
        return item

    def spider_closed(self, spider):
        print('SPIDER FINISHED!')    