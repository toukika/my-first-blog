from django.contrib import admin
from mianApp.models import NameItem
# Register your models here.
