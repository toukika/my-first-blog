from django.db import models

# Create your models here.
class NameItem(models.Model):
	name = models.CharField(max_length = 50)
	number = models.IntegerField(default=100)
	category = models.CharField(max_length = 30)

#class Meta():
	#db_table='nameitem'