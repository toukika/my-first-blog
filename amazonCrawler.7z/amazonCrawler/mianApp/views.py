from django.core.paginator import Paginator
from django.http import HttpResponse
from django.shortcuts import render


#scrapyd = ScrapydAPI('http://localhost:6800')
# Create your views here.


def index(request):
    return render(request, 'index.html')

def detail(request, num=1):
    list = NameItem.objects.order_by('-name')
    paginator = Paginator(list, 10)

    page = paginator.page(num)

    return render(request, 'index.html', {'spotList': page, 'key': 'detail'})

