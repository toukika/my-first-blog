from django.apps import AppConfig


class MianappConfig(AppConfig):
    name = 'mianApp'
