#coding=utf-8
#!/usr/bin/env python
import os

os.system('python manage.py runserver 8001')
