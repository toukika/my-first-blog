//测试域名
var domain_name = "";