#coding=utf-8
from scrapy import spiders
from comicspider.spiders import manhua163Spider,shenmanhuaSpider,tencentSpider
def getSpider(url):
    if 'manhua.163.com' in url:
        return manhua163Spider.manhua163
    elif 'www.shenmanhua.com' in url:
        # print 1
        return shenmanhuaSpider.shenmanhua
    elif 'ac.qq.com' in url:
        # print 1
        return tencentSpider.tencentSpider
