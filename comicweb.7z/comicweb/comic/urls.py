#coding=utf-8
from django.conf.urls import url
from . import views
from django.urls import path

urlpatterns = [
    path('getContent',views.getContent,name='getContent'),
    path('',views.index,name='index'),
    # url(r'^test$',views.test,name='test'),
    path('getComicInfo',views.getComicInfo,name='getComicsInfo'),
    path('preChapter',views.preChapter,name='preChapter'),
    path('nextChapter',views.nextChapter,name='nextChapter'),
    path('indexMore',views.indexMore,name='indexMore'),
    path('search',views.search,name='search'),
]